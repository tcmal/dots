//css_pc Precompilers/auto_method
//css_pc Precompilers/dsl

print("args start ----");

foreach (arg in args)
	print(arg);
	
print("args end ----");

print("\nStrings...");

foreach(str in strings{"aaa", "bbb", "ccc"})
	print("  " + str);

msgbox("Just a test...");

