using System;
using System.Windows.Forms;

class Script
{
	[STAThread]
	static public void Main(string[] args)
	{
		MessageBox.Show("Just a test! (Decrypted)");
	}
}

